package org.qshp.commons.generatecode.javaproject;

/**
 * Created by muyu on 15/11/14.
 * 普通Java工程
 */
public interface JavaProject extends Project_ {

    /**
     * 生成project src/main/java package
     * @return String java package
     */
    String generateJavaPackage();

    /**
     * 生成project src/test/java  package
     * @return String test package
     */
    String generateTestPackage();

}
