package org.qshp.commons.generatecode.javaproject;

import org.apache.commons.configuration.Configuration;
import org.apache.commons.lang.ArrayUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.net.URI;

/**
 * Created by muyu on 15/12/11.
 */
public abstract class AbstractWebProject extends DefaultJavaProject implements WebProject {

    final Logger logger = LoggerFactory.getLogger(AbstractWebProject.class);

    public final String WEB_PROJECT_DIR_FLAG = "web.project.dir";

    public final String TEMPLATE_WEB_POM_PATH = "project-template/demo-web/pom.xml";

    private String projectDir;

    public AbstractWebProject(Configuration config) {
        super(config);
        this.projectDir = config.getString(WEB_PROJECT_DIR_FLAG);
    }

    public void buildProject(){
        generateResource();
        generateWebapp();
    }

    @Override
    public String getTempatePomPath(){
        return TEMPLATE_WEB_POM_PATH;
    }

    @Override
    public String getProjectDir() {
        return projectDir;
    }

    @Override
    public String[] generateResource() {
        String[] filePaths = generateResourceProperties();
        filePaths = (String[])ArrayUtils.addAll(filePaths, generateResourceSpring());
        filePaths = (String[])ArrayUtils.add(filePaths, generateResourceLog4j());
        return filePaths;
    }

    @Override
    public String[] generateWebapp() {
        String[] filePaths = generateAssetsCssDir();
        filePaths = (String[])ArrayUtils.add(filePaths, generateAssetsImgDir());
        filePaths = (String[])ArrayUtils.add(filePaths, generateAssetsJsDir());
        filePaths = (String[])ArrayUtils.addAll(filePaths, generateWebInfoLayout());
        filePaths = (String[])ArrayUtils.addAll(filePaths, generateWebInfoMacro());
        filePaths = (String[])ArrayUtils.addAll(filePaths, generateWebInfoVm());
        filePaths = (String[])ArrayUtils.add(filePaths, generateWebInfoWebXml());
        return filePaths;
    }

    public abstract String[] generateResourceProperties();

    public abstract String[] generateResourceSpring();

    public abstract String generateResourceLog4j();

    public abstract String generateAssetsJsDir();

    public abstract String generateAssetsImgDir();

    public abstract String[] generateAssetsCssDir();

    public abstract String[] generateWebInfoLayout();

    public abstract String[] generateWebInfoMacro();

    public abstract String[] generateWebInfoVm();

    public abstract String generateWebInfoWebXml();


}
