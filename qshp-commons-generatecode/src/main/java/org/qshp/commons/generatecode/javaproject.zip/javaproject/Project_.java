package org.qshp.commons.generatecode.javaproject;

/**
 * Created by muyu on 15/11/14.
 */
public interface Project_ {

    /**
     * 生成project pom 文件
     * @return String pom 文件内容
     */
    String generatePom();

}
