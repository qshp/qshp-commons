package org.qshp.commons.generatecode.javaproject;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.configuration.Configuration;
import org.apache.commons.lang.ArrayUtils;
import org.qshp.commons.util.io.FileUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.net.URISyntaxException;
import java.util.Collections;
import java.util.Map;

/**
 * Created by muyu on 15/11/29.
 */
public class DefaultWebProject extends AbstractWebProject {

    final Logger logger = LoggerFactory.getLogger(DefaultWebProject.class);

    public final String TEMPLATE_ROOT_PATH = "project-template/demo-web";

    public final String RESOURCE_PROPERTIES_CONFIG = "/src/main/resources/config.properties";

    public final String RESOURCE_PATH = "/src/main/resources";

    public final String RESOURCE_SPRING_PATH = "/spring";

    public final String WEBAPP_PATH = "/src/main/webapp";

    public DefaultWebProject(Configuration config) {
        super(config);
    }

    @Override
    public String[] generateResourceProperties() {
        File resourceDir = FileUtils.mkdirs(getProjectDir() + RESOURCE_PROPERTIES_CONFIG);
        return new String[]{resourceDir.getPath()};
    }

    @Override
    public String[] generateResourceSpring() {
        return generateFileForDir(springTemplatePath());
    }

    @Override
    public String generateResourceLog4j() {
        return null;
    }

    @Override
    public String generateAssetsJsDir() {
        return null;
    }

    @Override
    public String generateAssetsImgDir() {
        return null;
    }

    @Override
    public String[] generateAssetsCssDir() {
        return new String[0];
    }

    @Override
    public String[] generateWebInfoLayout() {
        return new String[0];
    }

    @Override
    public String[] generateWebInfoMacro() {
        return new String[0];
    }

    @Override
    public String[] generateWebInfoVm() {
        return new String[0];
    }

    @Override
    public String generateWebInfoWebXml() {
        return null;
    }

    private String[] generateFileForDir(String tempatePath){
        File tempatePathFile ;
        try {
            tempatePathFile = new File(ClassLoader.getSystemResource(tempatePath).toURI());
        } catch (URISyntaxException e) {
            throw new ProjectException("template path error !",e);
        }
        File[] childFiles = tempatePathFile.listFiles();
        if(ArrayUtils.isEmpty(childFiles)){
            return ArrayUtils.EMPTY_STRING_ARRAY;
        }
        File childFile;
        String[] childFilePath = new String[childFiles.length];
        String targetFile;
        for (int i=0;i<childFiles.length;i++){
            childFile = childFiles[i];
            if(childFile.isFile()){
                targetFile = springPath()+File.separator+childFile.getName();
                generateFile(new File(childFile.getPath()),new File(targetFile));
                childFilePath[i] = targetFile;
            }
        }
        return childFilePath;
    }


    public String springTemplatePath(){
        return TEMPLATE_ROOT_PATH+RESOURCE_PATH+RESOURCE_SPRING_PATH;
    }

    public String springPath(){
        return getProjectDir()+RESOURCE_PATH+RESOURCE_SPRING_PATH;
    }


}
