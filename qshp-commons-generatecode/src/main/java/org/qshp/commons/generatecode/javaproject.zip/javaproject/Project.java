package org.qshp.commons.generatecode.javaproject;

/**
 * Created by muyu on 15/12/13.
 */
public interface ProjectFactory {

    String templateDir();

    void buildProject();
}
