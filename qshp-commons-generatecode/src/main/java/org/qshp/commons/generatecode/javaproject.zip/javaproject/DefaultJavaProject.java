package org.qshp.commons.generatecode.javaproject;

import org.apache.commons.configuration.Configuration;
import org.qshp.commons.generatecode.util.FileParse;
import org.qshp.commons.util.io.FileUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.*;
import java.net.URI;
import java.net.URISyntaxException;

/**
 * Created by muyu on 15/11/15.
 */
public class DefaultJavaProject implements JavaProject {

    final Logger logger = LoggerFactory.getLogger(DefaultJavaProject.class);

    public final String PROJECT_DIR_FLAG = "project.dir";

//    public final String TEMPLATE_PATH = "project-template";

    public final String TEMPLATE_POM_PATH = "project-template/pom.xml";

    public final String POM_FILE_PATH = "/pom.xml";

    public final String JAVA_PACKAGE_PATH = "/src/main/java";

    public final String TEST_PACKAGE_PATH = "/src/test/java";

    private String projectDir;

    private Configuration config ;

    public DefaultJavaProject(Configuration config){
        this.projectDir = config.getString(PROJECT_DIR_FLAG);
        this.config = config;
    }

    @Override
    public String generateJavaPackage() {
        File javaPackage = FileUtils.mkdirs(getProjectDir() + JAVA_PACKAGE_PATH);
        return javaPackage.getPath();
    }

    @Override
    public String generateTestPackage() {
        File javaPackage = FileUtils.mkdirs(getProjectDir() + TEST_PACKAGE_PATH);
        return javaPackage.getPath();

    }

    @Override
    public String generatePom() {
        try {
            File tempate = new File(ClassLoader.getSystemResource(getTempatePomPath()).toURI());
            File target = new File(getProjectDir() + POM_FILE_PATH);
            return generateFile(tempate, target);
        } catch (URISyntaxException e){
            throw new ProjectException("template file not found !");
        }
    }



    public String generateFile(File template,File target) {
        BufferedReader reader;
        String fileContent;
        try {
            reader = new BufferedReader(new FileReader(template));
            FileParse parse = new FileParse(config);
            fileContent = parse.parseTemplate(reader).toString();
        } catch (FileNotFoundException e){
            throw new ProjectException("template file not found !");
        }

        try {
            File parentFile = target.getParentFile();
            if(!parentFile.exists()){
                parentFile.mkdirs();
            }
            FileOutputStream output = new FileOutputStream(target);
            output.write(fileContent.getBytes());
        } catch (IOException e) {
            throw new ProjectException("write target file error !");
        }
        return fileContent;
    }



    public String getTempatePomPath() throws URISyntaxException {
        return TEMPLATE_POM_PATH;
    }

    public String getProjectDir() {
        return projectDir;
    }

    public Configuration getConfig() {
        return config;
    }
}
