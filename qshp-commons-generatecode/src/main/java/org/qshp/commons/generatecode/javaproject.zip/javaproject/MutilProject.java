package org.qshp.commons.generatecode.javaproject;

/**
 * Created by muyu on 15/12/13.
 */
public class MutilProject implements ProjectFactory {

    String templateDir();

    void buildProject();
}
