package org.qshp.commons.generatecode.javaproject;

/**
 * Created by muyu on 15/11/29.
 */
public class MutiProjectFactory implements ProjectFactory {
    @Override
    public void buildProject() {

    }
}
