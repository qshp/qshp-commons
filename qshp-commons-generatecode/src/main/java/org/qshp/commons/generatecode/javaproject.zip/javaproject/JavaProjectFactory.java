package org.qshp.commons.generatecode.javaproject;

/**
 * Created by muyu on 15/11/15.
 */
public class JavaProjectFactory implements ProjectFactory {

    private JavaProject project;

    private String groupId;

    private String artifactId;

    public JavaProjectFactory(JavaProject project){
        this.project = project;
    }

    @Override
    public void buildProject() {

    }
}
