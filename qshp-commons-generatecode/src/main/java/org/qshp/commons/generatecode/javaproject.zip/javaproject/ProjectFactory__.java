package org.qshp.commons.generatecode.javaproject;

/**
 * Created by muyu on 15/11/15.
 */
public interface ProjectFactory__ {

    /**
     * 自动生成工程
     */
    void buildProject();

}
