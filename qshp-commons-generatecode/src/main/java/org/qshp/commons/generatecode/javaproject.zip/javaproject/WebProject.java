package org.qshp.commons.generatecode.javaproject;

import java.io.File;
import java.util.Map;

/**
 * Created by muyu on 15/11/15.
 * Web Java工程
 */
public interface WebProject extends JavaProject {

    /**
     * 生成工程资源文件
     * @return
     */
    String[] generateResource();

    /**
     * 生成web project webapp 文件
     * @return String[] webapp 相关文件路径集
     * webapp 文件包括：js、css、img、WEB-INF
     */
    String[] generateWebapp();
}
